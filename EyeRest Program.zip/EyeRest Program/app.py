from flask import Flask, render_template, jsonify, request
import json
from datetime import datetime
import os

app = Flask(__name__)

# Mock data for supervisor dashboard
MOCK_EMPLOYEES = [
    {
        "id": 1,
        "name": "John Doe",
        "mental_health_score": 85,
        "breaks_taken": 3,
        "last_break": "2 hours ago",
        "status": "Active",
        "burnout_risk": "Low"
    },
    {
        "id": 2,
        "name": "Jane Smith",
        "mental_health_score": 65,
        "breaks_taken": 1,
        "last_break": "4 hours ago",
        "status": "Warning",
        "burnout_risk": "Medium"
    },
    {
        "id": 3,
        "name": "Mike Johnson",
        "mental_health_score": 45,
        "breaks_taken": 0,
        "last_break": "6 hours ago",
        "status": "Critical",
        "burnout_risk": "High"
    }
]

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/pricing')
def pricing():
    return render_template('pricing.html')

@app.route('/team')
def team():
    return render_template('team.html')

@app.route('/choose_role')
def choose_role():
    return render_template('choose_role.html')

@app.route('/employee')
def employee():
    return render_template('employee.html')

@app.route('/supervisor')
def supervisor():
    return render_template('supervisor.html', employees=MOCK_EMPLOYEES)

@app.route('/api/employees')
def get_employees():
    return jsonify(MOCK_EMPLOYEES)

if __name__ == '__main__':
    app.run(debug=True) 