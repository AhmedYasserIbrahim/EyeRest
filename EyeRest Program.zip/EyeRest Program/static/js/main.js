// Function to show burnout alert modal
function showBurnoutAlert() {
    const recommendations = [
        "Take a 5-minute walk to refresh your mind and boost circulation",
        "Practice the 20-20-20 rule: Look at something 20 feet away for 20 seconds",
        "Do some gentle neck and shoulder stretches to release tension",
        "Try deep breathing exercises: Inhale for 4 seconds, hold for 4, exhale for 4",
        "Drink water and stay hydrated for better cognitive function",
        "Stand up and do some light stretching exercises",
        "Close your eyes for 30 seconds and practice mindful breathing",
        "Adjust your posture and ensure proper screen height",
        "Do some wrist and hand exercises to prevent strain",
        "Consider switching tasks to give your eyes a different focus"
    ];

    const randomRecs = [];
    while (randomRecs.length < 3) {
        const rec = recommendations[Math.floor(Math.random() * recommendations.length)];
        if (!randomRecs.includes(rec)) {
            randomRecs.push(rec);
        }
    }
    
    const modalHTML = `
        <div class="modal-backdrop"></div>
        <div class="burnout-modal">
            <h2 class="text-center mb-4" style="color: #4a90e2;">Burnout Risk Detected!</h2>
            <p class="lead">We've noticed signs of potential burnout. Here are some recommendations:</p>
            <ul class="recommendations-list mb-4">
                ${randomRecs.map(rec => `<li class="mb-2">${rec}</li>`).join('')}
            </ul>
            <div class="text-center">
                <button class="btn btn-primary me-3" onclick="startBreakTimer()">Take a 5-min Break</button>
                <button class="btn btn-outline-light" onclick="dismissModal()">Continue Working</button>
            </div>
        </div>
    `;

    const modalContainer = document.createElement('div');
    modalContainer.innerHTML = modalHTML;
    document.body.appendChild(modalContainer);
}

function dismissModal() {
    const modal = document.querySelector('.modal-backdrop')?.parentElement;
    if (modal) {
        modal.remove();
    }
}

function startBreakTimer() {
    const modal = document.querySelector('.burnout-modal');
    if (modal) {
        let timeLeft = 5 * 60; // 5 minutes in seconds
        modal.innerHTML = `
            <h2 class="text-center mb-4" style="color: #4a90e2;">Break Time</h2>
            <div class="timer-display">05:00</div>
            <p class="text-center">Take this time to relax and recharge.</p>
            <p class="text-center">Your screen will be unlocked when the timer ends.</p>
        `;

        const timerInterval = setInterval(() => {
            timeLeft--;
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            const display = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            
            const timerDisplay = modal.querySelector('.timer-display');
            if (timerDisplay) {
                timerDisplay.textContent = display;
            }

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                dismissModal();
            }
        }, 1000);
    }
}

// Initialize charts for supervisor dashboard
function initializeCharts() {
    const ctx = document.getElementById('employeeMetricsChart');
    if (ctx) {
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['John Doe', 'Jane Smith', 'Mike Johnson'],
                datasets: [{
                    label: 'Mental Health Score',
                    data: [85, 65, 45],
                    backgroundColor: [
                        'rgba(46, 204, 113, 0.5)',
                        'rgba(241, 196, 15, 0.5)',
                        'rgba(231, 76, 60, 0.5)'
                    ],
                    borderColor: [
                        'rgba(46, 204, 113, 1)',
                        'rgba(241, 196, 15, 1)',
                        'rgba(231, 76, 60, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
}

// Initialize page based on role
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the employee page
    if (document.querySelector('.employee-content')) {
        setTimeout(showBurnoutAlert, 20000); // Show alert after 20 seconds
    }

    // Initialize charts if we're on the supervisor page
    if (document.querySelector('.supervisor-dashboard')) {
        initializeCharts();
    }
}); 